from PIL import Image

file_name = "1_Limniu 2021_1_2021_06_02-13-08-37-958.PNG"

image = Image.open(file_name)

print(image.size)
print(image.filename)
print(image.format)

image.show()

cat_rotated = image.rotate(30, expand=True)
cat_rotated.save('cat_rotated.png', 'png')
cat_rotated.show()